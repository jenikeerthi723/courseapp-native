import React from 'react';
import './ExternalCSSExample.css'

class ExternalCSSExample extends React.Component {
    render() {
      
      return (
            <div className="divcontainer">
                <h1 className="h1container">Clayfin - External CSS !!!</h1>
            </div>
      );
    }
  }

export default ExternalCSSExample;