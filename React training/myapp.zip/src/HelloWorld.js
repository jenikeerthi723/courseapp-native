import React from 'react';


class HelloWorld extends React.Component {

    render() {
      const ele = <div>Hello World </div>
      return (
        <div>
          {ele}
          </div>
      )
    }
  }

  export default HelloWorld;