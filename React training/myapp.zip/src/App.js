import React from 'react';

// import HelloWorld from './HelloWorld';
// import ParentChild from './ParentChild';
// import PropChildExample from './PropChildExample'
// import PropTypesExample from './PropTypesExample'
//import ChildParent from './ChildParent'
// import TempCalc from './TempCalc/TempCalc'
// import TodoApp from './TodoApp'
// import RefsExample from './RefsExample'
// import GlobalStyleExample from './Styles/GlobalStyleExample'
// import InlineStyleExample1 from './Styles/InlineStyleExample1'
// import InlineStyleExample2 from './Styles/InlineStyleExample2'
// import ExternalCSSExample from './Styles/ExternalCSSExample'
// import CssModuleExample from './Styles/CssModuleExample'
// import SingleElementForm from './SingleElementForm'
// import TwoElementForm from './TwoElementForm'
// import MultiSelect from './MultiSelect'
// import FormContainer1 from './FormContainer/FormContainer1/FormContainer1'
import LifeCycleExample1 from './LifeCycle/LifeCycleExample1'


function App() {
  return (
   <LifeCycleExample1  />
  );
}

export default App;
