import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';

// import HelloWorld from './HelloWorld'
// import ViewStyleExample from './ViewStyleExample'
// import ViewClickExample from './ViewClickExample'
// import TextExample from './TextExample'
// import FixedDimensions from './FixedDimensions'
// import FlexTest from './FlexBox/Flex/FlexTest'
// import FlexDirectionTest from './FlexBox/FlexDirection/FlexDirectionTest'
// import FlexWrapTest from './FlexBox/FlexWrap/FlexWrapTest'
// import JustifyContent from './FlexBox/JustifyContent/JustifyContentTest'
// import AlignItemsTest from './FlexBox/AlignItems/AlignItemsTest'
// import JustifyContentAlignItems from './FlexBox/JustifyContentAlignItems/JustifyContentAlignItemsTest'
// import AlignContent from './FlexBox/AlignContent/AlignContentTest'
// import AlignSelf from  './FlexBox/AlignSelf/AlignSelfTest'
// import PositionTest from './PositionTest'
import DimensionsTest from './DimensionsTest'

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <View  style={styles.container}>
         <DimensionsTest />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',
  }
});

export default App;
